class Membranepump:
    def __init__(self, device):
        self.device = device
        self.interface_name = "com.attocube.cryostat.interface.membranePump"



