from .AMC import Device as AMC
from .CRYO2100 import Device as CRYO2100
from .CRYO800 import Device as CRYO800
from .CRYOEVU import Device as CRYOEVU
from .IDS import Device as IDS
