class Magnet:
    def __init__(self, device):
        self.device = device
        self.interface_name = "com.attocube.cryostat.interface.magnet"

    def downloadCalibrationCurve(self):
        # type: () -> (str)
        """
        Gets the magnet sensor calibration curve

        Returns:
            errorNumber: No error = 0calibration_data: 
        
        """
        
        response = self.device.request(self.interface_name + ".downloadCalibrationCurve")
        self.device.handleError(response)
        return response[1]                

    def downloadCalibrationCurve340(self):
        # type: () -> (str)
        """
        Gets the magnet sensor .340 calibration curve

        Returns:
            errorNumber: No error = 0calibration_data: 
        
        """
        
        response = self.device.request(self.interface_name + ".downloadCalibrationCurve340")
        self.device.handleError(response)
        return response[1]                

    def getDrivenMode(self, channel):
        # type: (int) -> (bool)
        """
        Let's reset the quench event

        Parameters:
            channel:         

        Returns:
            errorNumber: No error = 0drivenMode_on_or_off: 
        
        """
        
        response = self.device.request(self.interface_name + ".getDrivenMode", [channel, ])
        self.device.handleError(response)
        return response[1]                

    def getFieldControl(self, channel):
        # type: (int) -> (bool)
        """
        Get the magnetic field control

        Parameters:
            channel:         

        Returns:
            errorNumber: No error = 0field_control_status: 
        
        """
        
        response = self.device.request(self.interface_name + ".getFieldControl", [channel, ])
        self.device.handleError(response)
        return response[1]                

    def getH(self, channel):
        # type: (int) -> (float)
        """
        Gets the magnetic field

        Parameters:
            channel:         

        Returns:
            errorNumber: No error = 0field: 
        
        """
        
        response = self.device.request(self.interface_name + ".getH", [channel, ])
        self.device.handleError(response)
        return response[1]                

    def getHSetPoint(self, channel):
        # type: (int) -> (float)
        """
        Gets the magnet set point

        Parameters:
            channel:         

        Returns:
            errorNumber: No error = 0setPoint: 
        
        """
        
        response = self.device.request(self.interface_name + ".getHSetPoint", [channel, ])
        self.device.handleError(response)
        return response[1]                

    def getHSetPoint3D(self, setPointZ, setPointY, setPointX):
        # type: (float, float, float) -> ()
        """
        Sets the magnetic field set point

        Parameters:
            setPointZ: setPointY: setPointX:         
        """
        
        response = self.device.request(self.interface_name + ".getHSetPoint3D", [setPointZ, setPointY, setPointX, ])
        self.device.handleError(response)
        return                 

    def getHState(self, channel):
        # type: (int) -> (str)
        """
        Gets the magnetic set point field

        Parameters:
            channel:         

        Returns:
            errorNumber: No error = 0state: 
        
        """
        
        response = self.device.request(self.interface_name + ".getHState", [channel, ])
        self.device.handleError(response)
        return response[1]                

    def getInputFilterSettings(self):
        # type: () -> (bool, int, int)
        """
        Gets the magnet input filter settings

        Returns:
            errorNumber: No error = 0off_or_on: point: window: 
        
        """
        
        response = self.device.request(self.interface_name + ".getInputFilterSettings")
        self.device.handleError(response)
        return response[1], response[2], response[3]                

    def getMagnetChannelName(self, channel):
        # type: (int) -> (str)
        """
        Gets the number of magnets

        Parameters:
            channel: ----------        

        Returns:
            errorNumber: No error = 0name: 
        
        """
        
        response = self.device.request(self.interface_name + ".getMagnetChannelName", [channel, ])
        self.device.handleError(response)
        return response[1]                

    def getNumberOfMagnetChannels(self):
        # type: () -> (int)
        """
        Gets the number of magnets

        Returns:
            errorNumber: No error = 0channels: 
        
        """
        
        response = self.device.request(self.interface_name + ".getNumberOfMagnetChannels")
        self.device.handleError(response)
        return response[1]                

    def getPersistentMode(self, channel):
        # type: (int) -> (bool)
        """
        Gets the magnetic field

        Parameters:
            channel:         

        Returns:
            errorNumber: No error = 0onOrOff: 
        
        """
        
        response = self.device.request(self.interface_name + ".getPersistentMode", [channel, ])
        self.device.handleError(response)
        return response[1]                

    def getPersistentSwitchPresent(self, channel):
        # type: (int) -> (bool)
        """
        Gets the persistent switch option pressent in X direction

        Parameters:
            channel:         

        Returns:
            errorNumber: No error = 0present: 
        
        """
        
        response = self.device.request(self.interface_name + ".getPersistentSwitchPresent", [channel, ])
        self.device.handleError(response)
        return response[1]                

    def getResistance(self):
        # type: () -> (float)
        """
        Gets the magnet temperature resistance. There is only one for all magnets

        Returns:
            errorNumber: No error = 0resistance: 
        
        """
        
        response = self.device.request(self.interface_name + ".getResistance")
        self.device.handleError(response)
        return response[1]                

    def getTemperature(self):
        # type: () -> (float)
        """
        Gets the magnet temperature. There is only one for all magnets

        Returns:
            errorNumber: No error = 0temperature: 
        
        """
        
        response = self.device.request(self.interface_name + ".getTemperature")
        self.device.handleError(response)
        return response[1]                

    def getVolt(self, channel):
        # type: (int) -> (float)
        """
        Gets the magnetic field

        Parameters:
            channel:         

        Returns:
            errorNumber: No error = 0field: 
        
        """
        
        response = self.device.request(self.interface_name + ".getVolt", [channel, ])
        self.device.handleError(response)
        return response[1]                

    def postResetQuenchEvent(self, channel):
        # type: (int) -> ()
        """
        Let's reset the quench event

        Parameters:
            channel:         
        """
        
        response = self.device.request(self.interface_name + ".postResetQuenchEvent", [channel, ])
        self.device.handleError(response)
        return                 

    def setDrivenMode(self, onOrOff, channel):
        # type: (int, bool) -> ()
        """
        Let's reset the quench event

        Parameters:
            onOrOff: Parameters
----------channel:         
        """
        
        response = self.device.request(self.interface_name + ".setDrivenMode", [onOrOff, channel, ])
        self.device.handleError(response)
        return                 

    def setHSetPoint(self, channel, setPoint):
        # type: (int, float) -> ()
        """
        Sets the magnetic field set point

        Parameters:
            channel: setPoint:         
        """
        
        response = self.device.request(self.interface_name + ".setHSetPoint", [channel, setPoint, ])
        self.device.handleError(response)
        return                 

    def setInputFilterSettings(self, filterOn, numberOfPoints, windowSize):
        # type: (bool, int, int) -> ()
        """
        Sets the magnet input filter settings

        Parameters:
            filterOn: numberOfPoints: windowSize:         
        """
        
        response = self.device.request(self.interface_name + ".setInputFilterSettings", [filterOn, numberOfPoints, windowSize, ])
        self.device.handleError(response)
        return                 

    def setPersistentMode(self, channel, onOrOff):
        # type: (int, bool) -> ()
        """
        Sets the magnet persistent heater

        Parameters:
            channel: onOrOff:         
        """
        
        response = self.device.request(self.interface_name + ".setPersistentMode", [channel, onOrOff, ])
        self.device.handleError(response)
        return                 

    def startFieldControl(self, channel):
        # type: (int) -> ()
        """
        Starts the magnetic field control

        Parameters:
            channel:         
        """
        
        response = self.device.request(self.interface_name + ".startFieldControl", [channel, ])
        self.device.handleError(response)
        return                 

    def stopFieldControl(self, channel):
        # type: (int) -> ()
        """
        Stops the magnetic field control

        Parameters:
            channel:         
        """
        
        response = self.device.request(self.interface_name + ".stopFieldControl", [channel, ])
        self.device.handleError(response)
        return                 

    def uploadCalibrationCurve(self, calibrationData):
        # type: (str) -> ()
        """
        Sets the magnet sensor calibration curve    May time out, but the upload will still work

        Parameters:
            calibrationData:         
        """
        
        response = self.device.request(self.interface_name + ".uploadCalibrationCurve", [calibrationData, ])
        self.device.handleError(response)
        return                 

    def uploadCalibrationCurve340(self, calibrationData):
        # type: (str) -> ()
        """
        Sets the magnet sensor .340 calibration curve    May time out, but the upload will still work

        Parameters:
            calibrationData:         
        """
        
        response = self.device.request(self.interface_name + ".uploadCalibrationCurve340", [calibrationData, ])
        self.device.handleError(response)
        return                 

