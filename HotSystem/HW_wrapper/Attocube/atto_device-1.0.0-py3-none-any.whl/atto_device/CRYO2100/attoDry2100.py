from . import ACS
from .cryoOutValve import Cryooutvalve
from .dumpInValve import Dumpinvalve
from .sample import Sample
from .about import About
from .functions import Functions
from .system import System
from .system_service import System_service
from .network import Network
from .magnet import Magnet
from .scrollPump import Scrollpump
from .vti import Vti
from .dumpOutValve import Dumpoutvalve
from .update import Update
from .cryoInValve import Cryoinvalve
from .access import Access
from .action import Action
from .pressures import Pressures
from .condenser import Condenser
from .tboard import Tboard
from .main import Main
from .exchange import Exchange


class Device(ACS.Device):
    def __init__(self, address):
        super().__init__(address)

        self.cryoOutValve = Cryooutvalve(self)
        self.dumpInValve = Dumpinvalve(self)
        self.sample = Sample(self)
        self.about = About(self)
        self.functions = Functions(self)
        self.system = System(self)
        self.system_service = System_service(self)
        self.network = Network(self)
        self.magnet = Magnet(self)
        self.scrollPump = Scrollpump(self)
        self.vti = Vti(self)
        self.dumpOutValve = Dumpoutvalve(self)
        self.update = Update(self)
        self.cryoInValve = Cryoinvalve(self)
        self.access = Access(self)
        self.action = Action(self)
        self.pressures = Pressures(self)
        self.condenser = Condenser(self)
        self.tboard = Tboard(self)
        self.main = Main(self)
        self.exchange = Exchange(self)
        
        

def discover():
    return Device.discover("attodry2100")
