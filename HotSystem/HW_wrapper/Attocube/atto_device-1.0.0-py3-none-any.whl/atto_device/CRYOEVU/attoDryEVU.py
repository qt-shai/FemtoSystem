from . import ACS
from .valves import Valves
from .about import About
from .membranePump import Membranepump
from .system import System
from .tboard import Tboard
from .compressor import Compressor
from .turboPump import Turbopump
from .update import Update
from .main import Main
from .heater import Heater
from .network import Network
from .access import Access
from .system_service import System_service
from .scrollPump import Scrollpump
from .functions import Functions
from .pressures import Pressures


class Device(ACS.Device):
    def __init__(self, address):
        super().__init__(address)

        self.valves = Valves(self)
        self.about = About(self)
        self.membranePump = Membranepump(self)
        self.system = System(self)
        self.tboard = Tboard(self)
        self.compressor = Compressor(self)
        self.turboPump = Turbopump(self)
        self.update = Update(self)
        self.main = Main(self)
        self.heater = Heater(self)
        self.network = Network(self)
        self.access = Access(self)
        self.system_service = System_service(self)
        self.scrollPump = Scrollpump(self)
        self.functions = Functions(self)
        self.pressures = Pressures(self)
        
        

def discover():
    return Device.discover("attodryevu")
