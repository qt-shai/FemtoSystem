from . import ACS
from .move import Move
from .rtin import Rtin
from .diagnostic import Diagnostic
from .about import About
from .rotcomp import Rotcomp
from .amcids import Amcids
from .description import Description
from .functions import Functions
from .res import Res
from .network import Network
from .control import Control
from .access import Access
from .update import Update
from .system_service import System_service
from .status import Status
from .test import Test
from .rtout import Rtout


class Device(ACS.Device):
    def __init__(self, address):
        super().__init__(address)

        self.move = Move(self)
        self.rtin = Rtin(self)
        self.diagnostic = Diagnostic(self)
        self.about = About(self)
        self.rotcomp = Rotcomp(self)
        self.amcids = Amcids(self)
        self.description = Description(self)
        self.functions = Functions(self)
        self.res = Res(self)
        self.network = Network(self)
        self.control = Control(self)
        self.access = Access(self)
        self.update = Update(self)
        self.system_service = System_service(self)
        self.status = Status(self)
        self.test = Test(self)
        self.rtout = Rtout(self)
        
        

def discover():
    return Device.discover("amc")
