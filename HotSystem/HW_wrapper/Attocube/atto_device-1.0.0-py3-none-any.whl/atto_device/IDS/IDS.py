from . import ACS
from .network import Network
from .nlc import Nlc
from .adjustment import Adjustment
from .ecu import Ecu
from .system_service import System_service
from .axis import Axis
from .access import Access
from .manual import Manual
from .realtime import Realtime
from .displacement import Displacement
from .pilotlaser import Pilotlaser
from .about import About
from .system import System
from .update import Update
from .functions import Functions
try:
    from streaming.streaming import Streaming
except:
    pass


class Device(ACS.Device):
    def __init__(self, address):
        super().__init__(address)

        self.network = Network(self)
        self.nlc = Nlc(self)
        self.adjustment = Adjustment(self)
        self.ecu = Ecu(self)
        self.system_service = System_service(self)
        self.axis = Axis(self)
        self.access = Access(self)
        self.manual = Manual(self)
        self.realtime = Realtime(self)
        self.displacement = Displacement(self)
        self.pilotlaser = Pilotlaser(self)
        self.about = About(self)
        self.system = System(self)
        self.update = Update(self)
        self.functions = Functions(self)
        
        try:
            self.streaming = Streaming(self)
        except NameError as e:
            if "Streaming" in str(e):
                print("Warning: Streaming is not supported on your platform")
            else:
                raise e
        

def discover():
    return Device.discover("ids")
